#include <stdio.h>
#include <math.h>
#include "cprob.h"

int main()
{
  printf("%f \n", lgam(5.2));
}
