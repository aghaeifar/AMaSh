#include <math.h>
int isnan2(double x) { return x != x; }
int isinf2(double x) { return !isnan2(x) && isnan2(x - x); }

int Xisnan(double x) { return isnan2(x); }
int Xisfinite(double x) { return isinf2(x); }
