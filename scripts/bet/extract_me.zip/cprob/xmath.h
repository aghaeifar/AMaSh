#if !defined(__XMATH_H)
#define __XMATH_H

int Xisnan(double);
int Xisfinite(double);

#endif
