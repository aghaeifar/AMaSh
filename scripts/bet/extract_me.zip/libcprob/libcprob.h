#if !defined(__LIBCPROB_H)
#define __LIBCPROB_H

#warning "This library is now deprecated. Please use the libprob library instead."

#if defined(__cplusplus)
namespace MISCMATHS {
#endif

#include "../cprob/cprob.h"

#if defined(__cplusplus)
}
#endif

#endif
